# reword-nerd prompt package

This package supports local One-shot and Manual rewriting workflows. It was generated locally and makes no provider call.

Open `OPEN-ME.html` for immediate document entry points. No exported HTML makes network requests or stores document data automatically.

| Document key | Source | One-shot | Manual | Combined | Full HTML |
| --- | --- | --- | --- | --- | --- |
| `garden--81f82dc303dd` | `documents/garden--81f82dc303dd/original.md` | `documents/garden--81f82dc303dd/one-shot/one-shot-prompt.html` | `documents/garden--81f82dc303dd/manual-prompts/manual-prompts.html` | `documents/garden--81f82dc303dd/combined-prompts/combined-prompts.html` | `documents/garden--81f82dc303dd/combined-prompts/combined-prompts-full.html` |

## `garden--81f82dc303dd`

Selected model: OpenAI / ChatGPT

Reference model: GPT-5.6 Sol

Guidance version: 2026-08-11-v1

Workflow note: Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

Resolved settings: {"tone":"plain","formality":"preserve","length":"preserve","outputLanguage":"Preserve source language","customRequirements":""}

Context estimates: One-shot 1616; Manual 3232; known limit: 1050000; required Manual warning acknowledged: not required.

Reviewed extraction: `documents/garden--81f82dc303dd/reviewed-extraction.md`

Canonical Manual prompts: `documents/garden--81f82dc303dd/manual-prompts/01-decompose.md`; `documents/garden--81f82dc303dd/manual-prompts/02-rewrite.md`; `documents/garden--81f82dc303dd/manual-prompts/03-verify.md`; `documents/garden--81f82dc303dd/manual-prompts/04-final.md`.

Visual assets: 0 included, 0 omitted; OCR records: 0; page count: not applicable.

When the model interface supports image input, attach included assets using the filenames in assets/index.md. Otherwise provide the asset catalog and reviewed OCR text. Preserve every stable asset ID and place each figure near the relevant rewritten discussion.

One-shot flow: copy `documents/garden--81f82dc303dd/one-shot/00-one-shot.md` into a new conversation. Expect only the marked final document and compact fidelity audit; intermediate reasoning remains internal.

1. Start a new conversation and run Stage 1.
2. Place the Stage 1 response in the matching marker, then run Stage 2.
3. Fill both prior-response markers and run Stage 3.
4. Fill all three markers, run Stage 4, and review the final output.

````text
Stage 1 marker: <<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
Stage 2 marker: <<<INSERT_STAGE_2_REWRITE_RESPONSE>>>
Stage 3 marker: <<<INSERT_STAGE_3_VERIFICATION_RESPONSE>>>
````

Replace only the response markers and keep instruction/source blocks intact.
