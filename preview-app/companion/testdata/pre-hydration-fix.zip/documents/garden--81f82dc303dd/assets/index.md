# Visual assets

Attach these files manually when the selected model interface supports image input. Preserve each stable ID and place the asset near the relevant rewritten discussion.

No extracted visual assets are included.
