# reword-nerd prompt package

This package supports local One-shot and Manual rewriting workflows. It was generated locally and makes no provider call.

Open `OPEN-ME.html` for immediate document entry points. No exported HTML makes network requests or stores document data automatically.

| Document key | Source | One-shot | Manual | Combined | Full HTML |
| --- | --- | --- | --- | --- | --- |
| `garden--81f82dc303dd` | `documents/garden--81f82dc303dd/original.md` | `documents/garden--81f82dc303dd/one-shot/one-shot-prompt.html` | `documents/garden--81f82dc303dd/manual-prompts/manual-prompts.html` | `documents/garden--81f82dc303dd/combined-prompts/combined-prompts.html` | `documents/garden--81f82dc303dd/combined-prompts/combined-prompts-full.html` |

## `garden--81f82dc303dd`

Selected model: OpenAI / ChatGPT

Reference model: GPT-5.6 Sol

Guidance version: 2026-08-11-v1

Workflow note: Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

Resolved settings: {"tone":"plain","formality":"preserve","length":"preserve","outputLanguage":"Preserve source language","customRequirements":""}

Context estimates: One-shot 1616; Manual 3232; known limit: 1050000; required Manual warning acknowledged: not required.

Reviewed extraction: `documents/garden--81f82dc303dd/reviewed-extraction.md`

Canonical Manual prompts: `documents/garden--81f82dc303dd/manual-prompts/01-decompose.md`; `documents/garden--81f82dc303dd/manual-prompts/02-rewrite.md`; `documents/garden--81f82dc303dd/manual-prompts/03-verify.md`; `documents/garden--81f82dc303dd/manual-prompts/04-final.md`.

Visual assets: 0 included, 0 omitted; OCR records: 0; page count: not applicable.

When the model interface supports image input, attach included assets using the filenames in assets/index.md. Otherwise provide the asset catalog and reviewed OCR text. Preserve every stable asset ID and place each figure near the relevant rewritten discussion.

One-shot flow: copy `documents/garden--81f82dc303dd/one-shot/00-one-shot.md` into a new conversation. Expect only the marked final document and compact fidelity audit; intermediate reasoning remains internal.

1. Start a new conversation and run Stage 1.
2. Place the Stage 1 response in the matching marker, then run Stage 2.
3. Fill both prior-response markers and run Stage 3.
4. Fill all three markers, run Stage 4, and review the final output.

````text
Stage 1 marker: <<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
Stage 2 marker: <<<INSERT_STAGE_2_REWRITE_RESPONSE>>>
Stage 3 marker: <<<INSERT_STAGE_3_VERIFICATION_RESPONSE>>>
````

Replace only the response markers and keep instruction/source blocks intact.

---

# Combined prompts — Garden.md

## Visual assets

No separately extracted visual assets are included. For project sources, see Project assets in the Package README.

## One-shot

````text
# One-shot: Decompose, Rewrite, Verify, Final

You are performing a complete high-fidelity semantic rewrite in one response.

## Task

Perform all four stages internally:

1. Decompose the source into a complete semantic inventory.
2. Rewrite it with substantially different phrasing and structure while preserving every material claim, fact, relationship, constraint, protected term, citation, and ambiguity.
3. Verify the rewrite against both the source and the semantic inventory for omissions, unsupported additions, meaning changes, structural similarity, and preference adherence.
4. Repair every supported issue and finalize the rewritten document.

Keep the decomposition, draft rewrite, verification details, and other bulky intermediate work internal. Do not expose chain-of-thought or hidden reasoning.

## Fidelity Rules

- Use only the supplied source and document artifacts as evidence.
- Follow the selected tone, formality, length, output language, and custom requirements.
- Preserve all supported meaning while changing surface form substantially.
- Do not invent claims, evidence, citations, interpretations, assets, or LaTeX content.
- Preserve required visual assets, captions, references, and LaTeX structure according to the supplied fidelity contract.

## Required Output Contract

Return exactly two marked blocks in this order and no preamble or trailing commentary:

```text
<<<FINAL_DOCUMENT>>>
[Complete final rewritten document]
<<<END_FINAL_DOCUMENT>>>

<<<FIDELITY_AUDIT>>>
Meaning: PASS | REVIEW — [brief evidence-bound note]
Preferences: PASS | REVIEW — [brief note]
Assets and LaTeX: PASS | NOT APPLICABLE | REVIEW — [brief note]
Remaining uncertainties: None. | [compact list]
<<<END_FIDELITY_AUDIT>>>
```

Keep the fidelity audit compact. Do not include the decomposition, draft rewrite, detailed verification report, or process narrative.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
One-shot guidance version: 2026-08-11-v1
Start a new conversation for each document. One-shot performs Decompose, Rewrite, Verify, and Final internally in a single request.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Use the lean four-stage procedure internally, do not expose intermediate work, and emit only the marked final document and compact fidelity audit.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For the internal decomposition, inventory every included asset and its role. Preserve and place required assets in the rewrite, verify every reference and caption, then repair any supported fidelity issue before finalizing.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====
````

## Stage 1 — Decompose

````text
# Stage 1: Decompose

You are a precise semantic analyst. Your only job in this stage is to extract and organize the essential meaning of the provided document.

Do **not** rewrite the document yet. Do **not** improve style. Do **not** add new information.

## Task

Analyze the source document and produce a clear, structured decomposition that captures everything that must be preserved in a high-fidelity rewrite.

## Required Output Structure

Produce your response in the following Markdown structure:

```markdown
## Document Type & Purpose
[Brief classification: e.g. academic report, technical essay, policy memo, etc. + primary purpose]

## Core Thesis / Main Claim
[One clear paragraph stating the central argument or purpose]

## Key Claims & Supporting Points
- Claim 1: ...
  - Supporting evidence / reasoning: ...
- Claim 2: ...
  - Supporting evidence / reasoning: ...
[Continue as needed]

## Essential Facts, Data & Specifics
- [List concrete facts, numbers, names, dates, technical terms, or findings that must survive rewriting]

## Structure & Logical Flow
1. [Section / major movement 1]
2. [Section / major movement 2]
...

## Constraints & Tone Requirements
- Must preserve: [list critical elements]
- Preferred register: [academic / professional / neutral / etc.]
- Things that must not change in meaning: [any sensitive or precise statements]

## Open Questions / Ambiguities
[Note any places where the original is unclear or could be interpreted in multiple ways]
```

## Rules

- Capture every material claim, fact, constraint, relationship, protected term, citation, and ambiguity, even for long documents.
- Be exhaustive about meaning, but concise in wording: concision applies to wording, not coverage.
- Prefer bullet points and numbered lists for clarity.
- Do not invent content that is not present or strongly implied.
- If the document is long, continue until every material element is captured while keeping each entry compact.
- Output **only** the structured decomposition. No preamble or commentary outside the structure.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Current stage: Capture every material claim, fact, relationship, constraint, protected term, and ambiguity before rewriting.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For this stage, inventory every included visual asset, its caption or description, the claim it supports, its source location, and any placement uncertainty.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====
````

## Stage 2 — Rewrite

````text
# Stage 2: Rewrite

You are an expert writer performing a high-fidelity semantic rewrite.

You will receive:
1. The original source document
2. A structured semantic decomposition of that document

Your goal is to produce a new version of the document that:

- Preserves all essential meaning, claims, facts, and logical relationships identified in the decomposition
- Uses substantially different sentence structures, phrasing, paragraph organization, and transitions
- Maintains an appropriate professional or academic register
- Reads as natural, coherent prose (not a mechanical paraphrase)

## Instructions

1. Study the decomposition carefully. Treat it as the authoritative list of what must survive.
2. Write a complete new version of the document.
3. Change surface form aggressively while protecting meaning.
4. Do not add new claims, evidence, or interpretations that are not supported by the original + decomposition.
5. Do not omit material that the decomposition marked as essential.
6. You may reorganize sections and paragraph flow when doing so preserves logical relationships.
7. Follow the selected preferences for tone, formality, length, output language, and custom requirements.

## Output

Produce **only** the rewritten document.  
Do not include the decomposition, commentary, or explanations in your output.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Current stage: Return a complete rewrite that follows the decomposition while changing surface structure and phrasing substantially.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For this stage, place each required visual asset near the rewritten discussion it supports and preserve stable asset identifiers and figure references.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====

===== BEGIN STAGE 1 DECOMPOSITION =====
<<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
===== END STAGE 1 DECOMPOSITION =====
````

## Stage 3 — Verify

````text
# Stage 3: Verify

You are a rigorous verification specialist.

You will receive three artifacts:
1. The original source document
2. The semantic decomposition
3. The candidate rewrite

Your job is to check whether the rewrite successfully preserves the meaning captured in the decomposition while achieving genuine structural difference.

## Task

Perform a careful comparison and produce a structured verification report.

## Required Output Structure

```markdown
## Overall Assessment
[One of: PASS / PASS WITH MINOR ISSUES / NEEDS REVISION]
[Short justification]

## Coverage Check
- Fully preserved:
  - ...
- Partially preserved or weakened:
  - ...
- Missing or significantly distorted:
  - ...

## Structural Difference
[Brief evaluation of how different the surface form is from the original. Note any sections that remain too close.]

## Preference Adherence
[Assess whether the rewrite follows the selected tone, formality, length, output language, and custom requirements.]

## Specific Issues
1. [Issue description + location or quote]
2. ...

If there are no issues, write `None.` under this heading.

## Recommended Fixes
- [Concrete, actionable suggestions for the final pass]
```

## Rules

- Be strict about meaning preservation.
- Explicitly assess preference adherence.
- Prefer concrete observations over vague praise.
- If the rewrite is strong, say so clearly.
- Output **only** the verification report in the structure above.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Current stage: Compare the rewrite against the decomposition and source, and report concrete omissions, additions, or meaning changes.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For this stage, verify every included asset is referenced correctly, captions remain faithful, and no unsupported visual claim was introduced.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====

===== BEGIN STAGE 1 DECOMPOSITION =====
<<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
===== END STAGE 1 DECOMPOSITION =====

===== BEGIN STAGE 2 REWRITE =====
<<<INSERT_STAGE_2_REWRITE_RESPONSE>>>
===== END STAGE 2 REWRITE =====
````

## Stage 4 — Final

````text
# Stage 4: Final Pass

You are polishing a high-fidelity rewrite.

You will receive these required inputs:
1. The source document
2. The semantic decomposition
3. The current candidate rewrite
4. The verification report (which may contain issues and recommended fixes)

The source document, decomposition, rewrite, and verification report are all required.

## Task

Produce the final polished version of the document.

- Repair every supported issue flagged in the verification report.
- Cross-check against the source and decomposition before finalizing every repair.
- Improve clarity, flow, and readability where needed.
- Preserve the semantic gains already achieved.
- Do not re-introduce surface patterns that make the text too similar to the original.
- Do not add new substantive content.

## Output

Return only the final document.  
No commentary, no verification notes, no explanations.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Current stage: Repair only verified issues, preserve supported meaning, and return the polished document without process commentary.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For this stage, repair missing or incorrect visual placement. Propose a clearly identified description only when the source supplied no caption or alt text.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====

===== BEGIN STAGE 1 DECOMPOSITION =====
<<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
===== END STAGE 1 DECOMPOSITION =====

===== BEGIN STAGE 2 REWRITE =====
<<<INSERT_STAGE_2_REWRITE_RESPONSE>>>
===== END STAGE 2 REWRITE =====

===== BEGIN STAGE 3 VERIFICATION =====
<<<INSERT_STAGE_3_VERIFICATION_RESPONSE>>>
===== END STAGE 3 VERIFICATION =====
````
