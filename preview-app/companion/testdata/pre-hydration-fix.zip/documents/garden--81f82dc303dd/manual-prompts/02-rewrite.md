# Stage 2: Rewrite

You are an expert writer performing a high-fidelity semantic rewrite.

You will receive:
1. The original source document
2. A structured semantic decomposition of that document

Your goal is to produce a new version of the document that:

- Preserves all essential meaning, claims, facts, and logical relationships identified in the decomposition
- Uses substantially different sentence structures, phrasing, paragraph organization, and transitions
- Maintains an appropriate professional or academic register
- Reads as natural, coherent prose (not a mechanical paraphrase)

## Instructions

1. Study the decomposition carefully. Treat it as the authoritative list of what must survive.
2. Write a complete new version of the document.
3. Change surface form aggressively while protecting meaning.
4. Do not add new claims, evidence, or interpretations that are not supported by the original + decomposition.
5. Do not omit material that the decomposition marked as essential.
6. You may reorganize sections and paragraph flow when doing so preserves logical relationships.
7. Follow the selected preferences for tone, formality, length, output language, and custom requirements.

## Output

Produce **only** the rewritten document.  
Do not include the decomposition, commentary, or explanations in your output.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Current stage: Return a complete rewrite that follows the decomposition while changing surface structure and phrasing substantially.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For this stage, place each required visual asset near the rewritten discussion it supports and preserve stable asset identifiers and figure references.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====

===== BEGIN STAGE 1 DECOMPOSITION =====
<<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
===== END STAGE 1 DECOMPOSITION =====