# Stage 4: Final Pass

You are polishing a high-fidelity rewrite.

You will receive these required inputs:
1. The source document
2. The semantic decomposition
3. The current candidate rewrite
4. The verification report (which may contain issues and recommended fixes)

The source document, decomposition, rewrite, and verification report are all required.

## Task

Produce the final polished version of the document.

- Repair every supported issue flagged in the verification report.
- Cross-check against the source and decomposition before finalizing every repair.
- Improve clarity, flow, and readability where needed.
- Preserve the semantic gains already achieved.
- Do not re-introduce surface patterns that make the text too similar to the original.
- Do not add new substantive content.

## Output

Return only the final document.  
No commentary, no verification notes, no explanations.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Current stage: Repair only verified issues, preserve supported meaning, and return the polished document without process commentary.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For this stage, repair missing or incorrect visual placement. Propose a clearly identified description only when the source supplied no caption or alt text.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====

===== BEGIN STAGE 1 DECOMPOSITION =====
<<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
===== END STAGE 1 DECOMPOSITION =====

===== BEGIN STAGE 2 REWRITE =====
<<<INSERT_STAGE_2_REWRITE_RESPONSE>>>
===== END STAGE 2 REWRITE =====

===== BEGIN STAGE 3 VERIFICATION =====
<<<INSERT_STAGE_3_VERIFICATION_RESPONSE>>>
===== END STAGE 3 VERIFICATION =====