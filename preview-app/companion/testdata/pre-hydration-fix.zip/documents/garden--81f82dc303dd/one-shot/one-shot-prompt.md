# reword-nerd prompt package

This package supports local One-shot and Manual rewriting workflows. It was generated locally and makes no provider call.

Open `OPEN-ME.html` for immediate document entry points. No exported HTML makes network requests or stores document data automatically.

| Document key | Source | One-shot | Manual | Combined | Full HTML |
| --- | --- | --- | --- | --- | --- |
| `garden--81f82dc303dd` | `documents/garden--81f82dc303dd/original.md` | `documents/garden--81f82dc303dd/one-shot/one-shot-prompt.html` | `documents/garden--81f82dc303dd/manual-prompts/manual-prompts.html` | `documents/garden--81f82dc303dd/combined-prompts/combined-prompts.html` | `documents/garden--81f82dc303dd/combined-prompts/combined-prompts-full.html` |

## `garden--81f82dc303dd`

Selected model: OpenAI / ChatGPT

Reference model: GPT-5.6 Sol

Guidance version: 2026-08-11-v1

Workflow note: Start a new conversation for each document, run the four prompts in order, and replace response markers with the previous stage outputs. Context limits vary by model and account; check them with the user before running the workflow.

Resolved settings: {"tone":"plain","formality":"preserve","length":"preserve","outputLanguage":"Preserve source language","customRequirements":""}

Context estimates: One-shot 1616; Manual 3232; known limit: 1050000; required Manual warning acknowledged: not required.

Reviewed extraction: `documents/garden--81f82dc303dd/reviewed-extraction.md`

Canonical Manual prompts: `documents/garden--81f82dc303dd/manual-prompts/01-decompose.md`; `documents/garden--81f82dc303dd/manual-prompts/02-rewrite.md`; `documents/garden--81f82dc303dd/manual-prompts/03-verify.md`; `documents/garden--81f82dc303dd/manual-prompts/04-final.md`.

Visual assets: 0 included, 0 omitted; OCR records: 0; page count: not applicable.

When the model interface supports image input, attach included assets using the filenames in assets/index.md. Otherwise provide the asset catalog and reviewed OCR text. Preserve every stable asset ID and place each figure near the relevant rewritten discussion.

One-shot flow: copy `documents/garden--81f82dc303dd/one-shot/00-one-shot.md` into a new conversation. Expect only the marked final document and compact fidelity audit; intermediate reasoning remains internal.

1. Start a new conversation and run Stage 1.
2. Place the Stage 1 response in the matching marker, then run Stage 2.
3. Fill both prior-response markers and run Stage 3.
4. Fill all three markers, run Stage 4, and review the final output.

````text
Stage 1 marker: <<<INSERT_STAGE_1_DECOMPOSITION_RESPONSE>>>
Stage 2 marker: <<<INSERT_STAGE_2_REWRITE_RESPONSE>>>
Stage 3 marker: <<<INSERT_STAGE_3_VERIFICATION_RESPONSE>>>
````

Replace only the response markers and keep instruction/source blocks intact.

---

# One-shot prompt — Garden.md

## Visual assets

No separately extracted visual assets are included. For project sources, see Project assets in the Package README.

## One-shot

````text
# One-shot: Decompose, Rewrite, Verify, Final

You are performing a complete high-fidelity semantic rewrite in one response.

## Task

Perform all four stages internally:

1. Decompose the source into a complete semantic inventory.
2. Rewrite it with substantially different phrasing and structure while preserving every material claim, fact, relationship, constraint, protected term, citation, and ambiguity.
3. Verify the rewrite against both the source and the semantic inventory for omissions, unsupported additions, meaning changes, structural similarity, and preference adherence.
4. Repair every supported issue and finalize the rewritten document.

Keep the decomposition, draft rewrite, verification details, and other bulky intermediate work internal. Do not expose chain-of-thought or hidden reasoning.

## Fidelity Rules

- Use only the supplied source and document artifacts as evidence.
- Follow the selected tone, formality, length, output language, and custom requirements.
- Preserve all supported meaning while changing surface form substantially.
- Do not invent claims, evidence, citations, interpretations, assets, or LaTeX content.
- Preserve required visual assets, captions, references, and LaTeX structure according to the supplied fidelity contract.

## Required Output Contract

Return exactly two marked blocks in this order and no preamble or trailing commentary:

```text
<<<FINAL_DOCUMENT>>>
[Complete final rewritten document]
<<<END_FINAL_DOCUMENT>>>

<<<FIDELITY_AUDIT>>>
Meaning: PASS | REVIEW — [brief evidence-bound note]
Preferences: PASS | REVIEW — [brief note]
Assets and LaTeX: PASS | NOT APPLICABLE | REVIEW — [brief note]
Remaining uncertainties: None. | [compact list]
<<<END_FIDELITY_AUDIT>>>
```

Keep the fidelity audit compact. Do not include the decomposition, draft rewrite, detailed verification report, or process narrative.

## Model Workflow
Selected model: OpenAI / ChatGPT
Reference model: GPT-5.6 Sol
Guidance version: 2026-08-11-v1
One-shot guidance version: 2026-08-11-v1
Start a new conversation for each document. One-shot performs Decompose, Rewrite, Verify, and Final internally in a single request.

## Model-Specific Execution Guidance
Keep the prompt lean and state each instruction once. Specify the outcome, relevant context, constraints, evidence boundary, and output format.
Use the lean four-stage procedure internally, do not expose intermediate work, and emit only the marked final document and compact fidelity audit.

## Rewrite Preferences
Tone: Plain
Formality: Preserve the source formality
Length: Preserve the source length
Output language: Preserve source language
===== BEGIN CUSTOM REQUIREMENTS =====
None.
===== END CUSTOM REQUIREMENTS =====

## Visual Asset Workflow
For the internal decomposition, inventory every included asset and its role. Preserve and place required assets in the rewrite, verify every reference and caption, then repair any supported fidelity issue before finalizing.
Attach the packaged files manually when the selected model interface supports image input. Otherwise use this catalog and the reviewed OCR text.

===== BEGIN VISUAL ASSET CATALOG =====
No extracted visual assets are included.
===== END VISUAL ASSET CATALOG =====

===== BEGIN SOURCE DOCUMENT =====
# A small shared garden

Our neighborhood garden opens on Saturday at 10 a.m. Bring water and a pair of gloves. Volunteers will plant herbs in three raised beds. Everyone is welcome, including people who have never gardened before.
===== END SOURCE DOCUMENT =====
````
